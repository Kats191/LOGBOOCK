# WIE
Esta tarea consiste en modificar la imagen de la pizarra que hizo Xiomara haciendo que destaque más el texto y clarear el fondo
